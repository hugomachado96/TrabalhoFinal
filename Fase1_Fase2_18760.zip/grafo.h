#ifndef _GRAFO_H_
#define _GRAFO_H_


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "meio.h"
#include "cliente.h"

typedef struct Vertice{
	char localizacao[100];
	struct Meio* meio;
	struct Clientes* cliente;
	struct Vertice* next;
}vertices;

typedef struct Aresta{
	struct Vertice* origem;
	struct Vertice* destino;
	float distancia;
	struct Aresta* next;
}arestas;

typedef struct Grafo{
	struct Vertice* vertices;
	struct Aresta* arestas;
}grafo;


vertices* encontrarVerticePorOpcao(grafo* g, int opcao);
vertices* criarVertice(char* localizacao, Meio* meios, Clientes* clientes);
arestas* criarAresta(vertices* v, grafo* g, int peso, char destino, char partida);
int imprimirVertices(grafo* g);
int adicionarLocalizacaoCliente(struct Grafo* g, Clientes* cliente, struct Vertice* verticeSelecionado);
struct Vertice* procurarVertice(struct vertices* v, char local[]);
grafo* menuGrafo(Clientes* cliente, grafo* g, vertices* v, arestas* a, Meio* meios);
grafo* criarGrafo();
vertices* removerVertice(vertices* v, char* local);
void imprimirArestas(arestas* a);

#endif
#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string.h>

#define VERTICES 5

#include "grafo.h"

vertices* criarVertice(vertices* v, char* localizacao, Meio* meios, Clientes* clientes) {
    vertices* novoVertice = (vertices*)malloc(sizeof(vertices));
    if (novoVertice == NULL) {
        printf("Erro ao alocar mem�ria para o v�rtice.\n");
        return v;
    }

    strcpy(novoVertice->localizacao, localizacao);
    novoVertice->meio = NULL;
    novoVertice->cliente = NULL;
    novoVertice->next = NULL;

    // Verifica os meios dispon�veis na localiza��o
    Meio* tempMeio = meios;
    while (tempMeio != NULL) {
        if (strcmp(tempMeio->localizacao, localizacao) == 0) {
            Meio* novoMeio = (Meio*)malloc(sizeof(Meio));
            if (novoMeio == NULL) {
                printf("Erro ao alocar mem�ria para o meio.\n");
                free(novoVertice);
                return v;
            }
            strcpy(novoMeio->tipo, tempMeio->tipo);
            novoMeio->next = NULL;

            if (novoVertice->meio == NULL) {
                novoVertice->meio = novoMeio;
            }
            else {
                Meio* ultimoMeio = novoVertice->meio;
                while (ultimoMeio->next != NULL) {
                    ultimoMeio = ultimoMeio->next;
                }
                ultimoMeio->next = novoMeio;
            }
        }
        tempMeio = tempMeio->next;
    }

    // Verifica os clientes na localiza��o
    Clientes* tempCliente = clientes;
    while (tempCliente != NULL) {
        if (strcmp(tempCliente->localizacao, localizacao) == 0) {
            Clientes* novoCliente = (Clientes*)malloc(sizeof(Clientes));
            if (novoCliente == NULL) {
                printf("Erro ao alocar mem�ria para o cliente.\n");
                free(novoVertice);
                return v;
            }
            strcpy(novoCliente->nome, tempCliente->nome);
            novoCliente->next = NULL;

            if (novoVertice->cliente == NULL) {
                novoVertice->cliente = novoCliente;
            }
            else {
                Clientes* ultimoCliente = novoVertice->cliente;
                while (ultimoCliente->next != NULL) {
                    ultimoCliente = ultimoCliente->next;
                }
                ultimoCliente->next = novoCliente;
            }
        }
        tempCliente = tempCliente->next;
    }

    if (v == NULL) {
        return novoVertice;
    }
    else {
        vertices* ultimoVertice = v;
        while (ultimoVertice->next != NULL) {
            ultimoVertice = ultimoVertice->next;
        }
        ultimoVertice->next = novoVertice;
        return v;
    }
}


vertices* encontrarVerticePorOpcao(grafo* g, int opcao) {
    vertices* vertice = g->vertices;
    int contador = 1;

    while (vertice != NULL) {
        if (contador == opcao) {
            return vertice;
        }
        vertice = vertice->next;
        contador++;
    }

    return NULL; // Op��o inv�lida, v�rtice n�o encontrado
}

arestas* criarAresta(vertices* v, grafo* g, int peso, char destino, char partida) {
    // Verifique se o v�rtice de destino e partida existem no grafo
    struct Vertice* verticeDestino = procurarVertice(g->vertices, destino);
    struct Vertice* verticePartida = procurarVertice(g->vertices, partida);

    if (verticeDestino == NULL || verticePartida == NULL) {
        printf("Erro: V�rtice de destino ou partida n�o encontrado!\n");
        return NULL;
    }

    // Crie uma nova aresta
    struct Aresta* novaAresta = (struct Aresta*)malloc(sizeof(struct Aresta));
    novaAresta->distancia = peso;
    novaAresta->destino = verticeDestino;
    novaAresta->origem = verticePartida;
    novaAresta->next = NULL;

    // Adicione a nova aresta ao v�rtice de partida
    /**if (v->arestas == NULL) {
        v->arestas = novaAresta;
    }
    else {
        struct Aresta* arestaAtual = v->arestas;
        while (arestaAtual->proxima != NULL) {
            arestaAtual = arestaAtual->proxima;
        }
        arestaAtual->proxima = novaAresta;
    }
    */
    return novaAresta;
}

int imprimirVertices(grafo* g) {
    if (g == NULL) {
        printf("Grafo vazio.\n");
        return 0;
    }

    vertices* atual = g->vertices;

    if (atual == NULL) {
        printf("Nenhum v�rtice encontrado.\n");
        return 0;
    }

    printf("V�rtices do grafo:\n");

    while (atual != NULL) {
        printf("Localiza��o: %s\n", atual->localizacao);
        atual = atual->next;
    }

    return 1;
}

int adicionarLocalizacaoCliente(struct Grafo* g, Clientes* cliente, struct Vertice* verticeSelecionado) {
    printf("Selecione a localizacao do cliente:\n");
    imprimirVertices(g);

    int opcao;
    char local[100];
    printf("Opcao: ");
    scanf("%d", &opcao);
    switch (opcao) {
    case 1:
        strcpy(cliente->localizacao, "Braga");
        strcpy(local, "Braga");
        break;
    case 2:
        strcpy(cliente->localizacao, "Barcelos");
        strcpy(local, "Barcelos");
        break;
    case 3:
        strcpy(cliente->localizacao, "Guimaraes");
        strcpy(local, "Guimaraes");
        break;
    case 4:
        strcpy(cliente->localizacao, "Famalicao");
        strcpy(local, "Famalicao");
        break;
    default:
        printf("Opcao invalida!\n");
        return 0;
    }

    verticeSelecionado = procurarVertice(g->vertices, local);
    if (verticeSelecionado == NULL) {
        printf("Localizacao nao encontrada!\n");
        return 0;
    }

    strcpy(cliente->localizacao, verticeSelecionado->localizacao);
    printf("Localizacao do cliente adicionada com sucesso!\n");
    return 1;
}

struct Vertice* procurarVertice(struct vertices* v, char local[]) {
    struct Vertice* verticeAtual = v;

    while (verticeAtual != NULL) {
        if (strcmp(verticeAtual->localizacao, local) == 0) {
            return verticeAtual;
        }
        verticeAtual = verticeAtual->next;
    }

    return NULL;  // Retorna NULL se o v�rtice n�o for encontrado
}

/*int existirVertice(vertices* v, char* localizacao) {
    vertices* verticeAtual = v;

    while (verticeAtual != NULL) {
        if (strcmp(verticeAtual->localizacao, localizacao) == 0) {
            return 1;  // O v�rtice existe na lista
        }
        verticeAtual = verticeAtual->next;
    }

    return 0;  // O v�rtice n�o existe na lista
}*/

grafo* criarGrafo() {
	grafo* g = (grafo*)malloc(sizeof(grafo));
	g->vertices = NULL;
	return g;
}

grafo* menuGrafo(Clientes* cliente, grafo* g, vertices* v, arestas* a, Meio* meios) {
    int opcao;
    char local[100], destino[100], partida[100];
    do {
        opcao = menuGrafos();
        switch (opcao) {
        case 1:
            imprimirVertices(g);
            break;
        case 2:
            printf("Insira o local do ponto de recolha: ");
            getchar();
            fgets(local, 100, stdin);
            local[strcspn(local, "\n")] = '\0';
            v = criarVertice(v, local, meios, cliente);
            system("PAUSE");
            break;
        case 3:
            printf("Insira a localizacao do ponto de recolha que quer remover: ");
            getchar();
            fgets(local, 100, stdin);
            local[strcspn(local, "\n")] = '\0';
            v = removerVertice(v, local);
            break;
        case 4:
            imprimirArestas(a);
            break;
        case 5:
            break;
        case 0:
            break;
        default:
            printf("Op��o invalida.");
            break;
        }
    } while (opcao != 0);
    return g;
}

vertices* removerVertice(vertices* v, char* local) {
    if (v == NULL) {
        printf("Erro: Grafo vazio.\n");
        return NULL;
    }

    vertices* atual = v;
    vertices* anterior = NULL;

    // Percorre a lista de v�rtices at� encontrar o v�rtice com a localiza��o desejada
    while (atual != NULL) {
        if (strcmp(atual->localizacao, local) == 0) {
            break;
        }
        anterior = atual;
        atual = atual->next;
    }

    // Se n�o encontrar o v�rtice com a localiza��o desejada
    if (atual == NULL) {
        printf("Erro: V�rtice n�o encontrado.\n");
        return v;
    }

    // Remove as conex�es do v�rtice atual
    desconectarVertices(v, atual);

    // Remove o v�rtice da lista
    if (anterior == NULL) {
        v = atual->next;
    }
    else {
        anterior->next = atual->next;
    }
    free(atual);

    return v;
}

void imprimirArestas(arestas* a) {
    if (a == NULL) {
        printf("Nenhuma aresta encontrada.\n");
        return;
    }

    printf("Arestas do v�rtice:\n");

    while (a != NULL) {
        printf("Origem: %s\n", a->origem->localizacao);
        printf("Destino: %s\n", a->destino->localizacao);
        printf("Distancia: %d\n", a->distancia);
        printf("\n");

        a = a->next;
    }
}

